
// var icon =chrome.extension.getURL('icons/icon19.png');	
var recognizing = false;
var ignore_onend;


function injectButton(AjaxDelay) 
{
	//var icon = chrome.extension.getURL('shared/img/icon48_white.png');
	try
	{
		setTimeout(function()
		{
			
			$("textarea").each(function(index) 
			{
				var id = $(this).attr("id");				
				$(this).after('<input type = "button" class="btn Merit_SST" id = Merit_SST_' + id + ' value = "Speak"/>');			
			});
			
			// $("textarea").after('<input type = "button" class="btn prakash" id = "start_button" value = "Speak"/>');			
			$(".Merit_SST").click(function()
			{
				var txtAreaID = $(this).attr("id").replace('Merit_SST_','');
				var btnID = $(this).attr("id");
				
				try
				{	
					if (!('webkitSpeechRecognition' in window)) 
					{			
						alert('Chrome version not supported. Upgrade your Chrome.');
					} 
					else 
					{			
						if (recognizing) 
						{
							recognition.stop();
							return;
						}			
						recognition = new webkitSpeechRecognition();
						recognition.continuous = true;
						recognition.interimResults = true;		
						recognition.onstart = function() 
						{
							recognizing = true;
							//showInfo('info_speak_now');
							$("#" + btnID).val('Stop');
						};
						
						recognition.onresult = function(event) 
						{
							try
							{
								recognizing = true;
								var interim_transcript = '';
								for (var i = event.resultIndex; i < event.results.length; ++i) 
								{
									if (event.results[i].isFinal) 
									{
										final_transcript += event.results[i][0].transcript;
									} 
									else 
									{
										interim_transcript += event.results[i][0].transcript;
									}
								}    
								$("#" + txtAreaID).val(interim_transcript);	
								if(final_transcript.length > 0)
									$("#" + txtAreaID).val(final_transcript);	
							}
							catch(err)
							{		
								alert(err.stack);
							}
						};
			  
						recognition.onend = function() 
						{
							recognizing = false;
							$("#" + btnID).val('Speak');
							if (ignore_onend) 
							{
								return;
							}  
						};
						
						recognition.onerror = function(event) 
						{
							$("#" + btnID).val('Speak');
							console.log(event.error);
							ignore_onend = true;
							// if (event.error == 'no-speech') 
							// {								
								// //showInfo('info_no_speech');
								
							// }
							// if (event.error == 'audio-capture') 
							// {
								// $("#" + btnID).val('Speak');
								// //showInfo('info_no_microphone');
								// ignore_onend = true;
							// }
							// if (event.error == 'not-allowed') 
							// {
								// if (event.timeStamp - start_timestamp < 100) 
								// {
									// showInfo('info_blocked');
								// } 
								// else 
								// {
									// showInfo('info_denied');
								// }
								// ignore_onend = true;
							// }
						};
			   
						final_transcript = '';
						recognition.lang = 'en-IN';
						recognition.start();  
						ignore_onend = false;
					}
				}
				catch(err)
				{		
					alert(err.stack);
				} 
			});							
		},AjaxDelay);		
	}
	catch(err)
	{
		console.log(err.stack);
	}  
}


  
var final_transcript = '';
var recognition;





try
{

//
// Start JS injection
//

//if(document.URL.indexOf('stackoverflow.com/questions')>-1)
if(document.URL.indexOf('salesforce.com')>-1)
{


	injectButton(100);
	// if(document.URL.indexOf('stackoverflow.com/questions')>-1)
	// {	
		// setInterval(function(){AddSearchProfiles_Button();}, 5000);
	// }
}

}
catch(err)
{
//alert(err.stack);
console.log(err.stack);
}



